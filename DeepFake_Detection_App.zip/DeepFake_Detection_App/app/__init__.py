from flask import Flask
import os

# Initialize Flask app
app = Flask(__name__)
secret_key = os.urandom(24)
app.config['SECRET_KEY'] = os.getenv('SECRET_KEY')

# Import routes after app initialization
from app import routes
