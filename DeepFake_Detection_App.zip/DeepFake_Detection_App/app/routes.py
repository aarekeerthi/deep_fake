from flask import Flask, render_template, request, redirect, url_for, send_file
from werkzeug.utils import secure_filename
import os
from utils.video_processing import process_video
from utils.inference import run_inference
from utils.report_generator import generate_report
from reportlab.lib.pagesizes import letter
from reportlab.pdfgen import canvas
import numpy as np
import io

app = Flask(__name__)

UPLOAD_FOLDER = 'app/uploads'
ALLOWED_EXTENSIONS = {'mp4', 'avi', 'mov'}
app.config['UPLOAD_FOLDER'] = UPLOAD_FOLDER

def allowed_file(filename):
    return '.' in filename and filename.rsplit('.', 1)[1].lower() in ALLOWED_EXTENSIONS

@app.route('/', methods=['GET', 'POST'])
def upload_file():
    if request.method == 'POST':
        if 'file' not in request.files:
            return redirect(request.url)
        file = request.files['file']
        if file.filename == '':
            return redirect(request.url)
        if file and allowed_file(file.filename):
            filename = secure_filename(file.filename)
            file_path = os.path.join(app.config['UPLOAD_FOLDER'], filename)
            file.save(file_path)
            
            processed_frames = process_video(file_path)
            predictions = run_inference(processed_frames)
            report = generate_report(predictions, file_path)
            
            # Save report to a file
            pdf_buffer = io.BytesIO()
            generate_pdf_report(report, pdf_buffer)
            pdf_buffer.seek(0)
            
            return send_file(pdf_buffer, as_attachment=True, download_name='report.pdf', mimetype='application/pdf')

    return render_template('index.html') 

def generate_pdf_report(report, buffer):
    c = canvas.Canvas(buffer, pagesize=letter)
    width, height = letter
    
    # Title
    c.setFont("Helvetica-Bold", 16)
    c.drawString(72, height - 72, "Deepfake Detection Report")
    
    # Video Path
    c.setFont("Helvetica", 12)
    c.drawString(72, height - 100, f"Video Path: {report['video_path']}")
    
    # Deepfake Probability
    c.drawString(72, height - 120, f"Deepfake Probability: {report['deepfake_probability']:.4f}")
    
    # Classification
    classification = "Deepfake" if report['is_deepfake'] else "Real"
    c.drawString(72, height - 140, f"Classification: {classification}")
    
    # Report Details
    details = [
        f"Total Frames: {report['details']['total_frames']}",
        f"Fake Frames: {report['details']['fake_frames']}",
        f"Real Frames: {report['details']['real_frames']}"
    ]
    
    y_position = height - 180
    for detail in details:
        c.drawString(72, y_position, detail)
        y_position -= 20
    
    c.save()
