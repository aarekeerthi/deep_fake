from app import app  # Import the app instance from your app/__init__.py

if __name__ == '__main__':
    app.run(debug=True)
