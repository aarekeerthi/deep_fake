import torch

# Function to load the pre-trained PyTorch model
def load_model_pytorch(model_path):
    # Load the model and ensure it's in evaluation mode
    model = torch.load(model_path)
    model.eval()  # Set the model to evaluation mode
    return model

# Function to run inference on the processed video frames
def run_inference(frames, model):
    device = torch.device('cuda' if torch.cuda.is_available() else 'cpu')
    
    # Move the model to the appropriate device (CPU or GPU)
    model.to(device)

    # Assume `frames` is a list of frame tensors (e.g., [frame1, frame2, ...])
    predictions = []

    for frame_tensor in frames:
        # Preprocessing (if required by the model):
        # Assuming the frame is a tensor of shape (C, H, W), add the batch dimension
        frame_tensor = frame_tensor.unsqueeze(0)  # Shape (1, C, H, W)

        # Move the frame tensor to the same device as the model
        frame_tensor = frame_tensor.to(device)

        # No need to track gradients during inference
        with torch.no_grad():
            # Forward pass through the model
            output = model(frame_tensor)

            # Apply a sigmoid if it's a binary classification task (e.g., deepfake vs real)
            probabilities = torch.sigmoid(output)

            # Get the prediction as a scalar (between 0 and 1)
            prediction = probabilities.item()

            # Append the prediction to the list
            predictions.append(prediction)
    
    # Return the predictions for all frames
    return predictions
