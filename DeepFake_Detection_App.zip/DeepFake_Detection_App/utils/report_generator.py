import numpy as np
def generate_report(predictions, video_path):
    deepfake_probability = np.mean(predictions)
    is_deepfake = deepfake_probability > 0.5
    
    report = {
        'video_path': video_path,
        'deepfake_probability': deepfake_probability,
        'is_deepfake': is_deepfake,
        'details': {
            'total_frames': len(predictions),
            'fake_frames': sum(p > 0.5 for p in predictions),
            'real_frames': sum(p <= 0.5 for p in predictions),
        }
    }
    
    return report
